@extends('layouts.mainlayout')

@section('content')

    <div class="row clearfix customerTb">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card">
                <div class="header">
                    <div class="row clearfix">
                        <div class="col-lg-4">
                            <h2>  Add New feature  </h2>
                        </div>
                        <div class="col-lg-8 align-right">
                           
                        </div>
                    </div>
                </div>

                <div class="body">
                    <h3>Need to implement this feature</h3>
                </div>
            </div>
        </div>
    </div>
    
      
@endsection

