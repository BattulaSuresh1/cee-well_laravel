<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use Illuminate\Http\Request;

class BrandController extends Controller
{
    public function index()
    {
        return Brand::all();
    }

    public function store(Request $request)
    {
        try 
        {
            $brand = new Brand();

            $brand->name = $request->name;

            $brand->save();

            $res = [
                "Success" => true,
                "Message" => 'New Brand Created Successfully'

            ];
            return response()->json($res);

        }catch(\Exception $e){
            $res = [
                'success' => false,
                'data' => 'Something went wrong.',
                'message' =>  $e->getMessage()
            ];

            return response()->json($res);
        }

    }

    public function BrandShow($id)
    {
        try 
        {
            $brand = Brand::find($id);

            $res = [
                'Success' => true,
                'Message' => 'Brand Details Found',
                'data' => $brand,
            ];

            return response()->json($res);
        }catch(\Exception $e)  
        {
            $res = [
                'Success' => false,
                'Message' => 'Something Went Wrong',
                'data'=> $e->getMessage()
            ];

            return response()->json($res);
        }
        
    }

    public function update(Request $request)
    {
        try
        {
            $data = Brand::find($request->id);
            $data->name = $request->name;
            $data->save();

            $res = [
                'Success' => true,
                'Message' => 'Brand Updated Successfully'
            ];
            return response()->json($res);

        }catch(\Exception $e)
        {
            $res = [
                'Success' => false,
                'Message' => 'Something went Wrong',
                'data'=> $e->getMessage()
            ];
            return response()->json($res);
        }
    }

    public function delete($id)
    {
        try
        {
            $data = Brand::find($id);
            $data->delete();

            $res = [
                'Success' => true,
                'Message' => 'Brand Deleted Successfully',
            ];
            
            return response()->json($res);
        }catch(\Exception $e)
        {
            $res = [
                'success' => false,
                'Message' => 'Something Went Wrong',
                'data'=> $e->getMessage()
            ];

            return response()->json($res);
        }
    }
}